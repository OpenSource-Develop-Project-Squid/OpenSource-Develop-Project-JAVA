package product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.UserBean;
import util.DatabaseUtil;

public class PrDAO {
	private ResultSet rs;
	
	public String getDate() {
		Connection conn = DatabaseUtil.getConnection();
		String SQL = "SELECT NOW()";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	public int getNext() {
		Connection conn = DatabaseUtil.getConnection();
		String SQL = "SELECT id FROM PRODUCT ORDER BY id DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	public int write(String name, String category, int price, String content,String user_id) {
		Connection conn = DatabaseUtil.getConnection();
		String SQL = "INSERT INTO PRODUCT VALUES(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, name);
			pstmt.setString(2, category);
			pstmt.setInt(3, price);
			pstmt.setString(4, content);
			pstmt.setString(5, getDate());
			pstmt.setInt(6, 1);
			pstmt.setInt(7,getNext());
			pstmt.setString(8,"");
			pstmt.setString(9,user_id);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	public ArrayList<Bean> getList(int pageNumber){
		Connection conn = DatabaseUtil.getConnection();
		String SQL = "SELECT * FROM PRODUCT WHERE id < ? AND bbsavailable = 1 ORDER BY id DESC LIMIT 6";
		ArrayList<Bean> list = new ArrayList<Bean>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1,getNext() - (pageNumber - 1) * 6);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Bean bean = new Bean();
				bean.setName(rs.getString(1));
				bean.setCategory(rs.getString(2));
				bean.setPrice(rs.getInt(3));
				bean.setContent(rs.getString(4));
				bean.setBbsdate(rs.getString(5));
				bean.setBbsavailable(rs.getInt(6));
				bean.setId(rs.getInt(7));
				bean.setAddress(rs.getString(8));
				bean.setUser_id(rs.getString(9));
				list.add(bean);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public boolean nextPage(int pageNumber) {
		Connection conn = DatabaseUtil.getConnection();
		String SQL = "SELECT * FROM PRODUCT WHERE id < ? AND bbsavailable = 1 ";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1,getNext() - (pageNumber - 1) * 6);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return false; 
	}
	
	//��ǰ�̹��� ����
	public void updateProductImg(String user_id, String path) {
		Connection conn = DatabaseUtil.getConnection();
		try {
			//�����غ�,,,,���� ���������� �� ���ϰ��ʹٸ� �޸��޸��� �÷������
			String sql = "update product set address=? where user_id=?";
			//�������� ��ü ����
			PreparedStatement pstmt = conn.prepareStatement(sql);
			//?�� ���� ����
			pstmt.setString(1, path);
			pstmt.setString(2, user_id);
			//��������
			pstmt.executeUpdate();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}